package com.rajinder.noticeboard.UI.ViewHolder;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;

public class FilterCategoryViewHolder extends RecyclerView.ViewHolder {

    private static Context mContext;

    public FilterCategoryViewHolder(View itemView) {
        super(itemView);
    }

}
