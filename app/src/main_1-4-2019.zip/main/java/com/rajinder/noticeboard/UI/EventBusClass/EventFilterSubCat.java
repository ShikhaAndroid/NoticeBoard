package com.rajinder.noticeboard.UI.EventBusClass;

public class EventFilterSubCat {

    int  position;

    public EventFilterSubCat() {}

    public EventFilterSubCat(int position) {
        this.position = position;
    }

    public int getPosition() {
        return position;
    }

}
