package com.rajinder.noticeboard.Utils;

import android.util.Log;

public class Utils {

    /*Log */
    public static void log(String str) {
        Log.d("noticetag", str);
    }

    /*server URL*/
    public static final String SERVER = "http://app.tuhadihatti.in/api/";
    public static final String NOTICE_BROAD_FILES_FOLDER = "notice broad";

}

//category