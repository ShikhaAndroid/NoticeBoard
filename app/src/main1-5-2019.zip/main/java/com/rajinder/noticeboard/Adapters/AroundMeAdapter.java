package com.rajinder.noticeboard.Adapters;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.support.annotation.NonNull;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.rajinder.noticeboard.Activity.HomeActivities.PostImagesListActivity;
import com.rajinder.noticeboard.Fragments.CategoryListFragment.AroundMeFragment;
import com.rajinder.noticeboard.Fragments.SpannedGridLayoutManager;
import com.rajinder.noticeboard.Interface.SpannedGridInterface;
import com.rajinder.noticeboard.R;
import com.rajinder.noticeboard.models.PostListModel;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class AroundMeAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public static final String TAG = "AroundMeAdapter";
    public static final int IMAGES = 2;
    public static final int TEXT_TYPE = 0;
    public static final int IMAGE_TYPE = 1;
    public static final int AUDIO_TYPE = 2;
    private int lastPosition = -1;

    private Context context;
    private Activity mActivity;
    private List<PostListModel> postListModels;
    private ItemAdapter.OnItemClickListener onItemClickListener;

    public AroundMeAdapter(Context mContext, List<PostListModel> postListModels, String type, ItemAdapter.OnItemClickListener onItemClickListener) {
        this.context = mContext;
        this.mActivity = (Activity) mContext;
        this.postListModels = postListModels;
        this.onItemClickListener = onItemClickListener;
//        this.type=type;
    }

    @Override
    public int getItemCount() {
        return postListModels.size();
    }

    @Override
    public int getItemViewType(int position) {
        switch (1) {    // postListModels.get(position).type
            case 0:
                return TEXT_TYPE;
            case 1:
                return IMAGE_TYPE;
            case 2:
                return AUDIO_TYPE;
            default:
                return -1;
        }
    }

    @NonNull
    @Override
    public AroundMeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        switch (viewType) {
            case TEXT_TYPE:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.template_around_me, parent, false);
                return new AroundMeViewHolder(view);
            case IMAGE_TYPE:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.template_around_me, parent, false);
                return new AroundMeViewHolder(view);
            case AUDIO_TYPE:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.template_around_me, parent, false);
                return new AroundMeViewHolder(view);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        setAnimation(holder.itemView, position);
        if (holder instanceof AroundMeViewHolder) {
            AroundMeViewHolder viewHolder = (AroundMeViewHolder) holder;
            Random rnd = new Random();
            int color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));

//            viewHolder.title.setText(postListModels.get(position).postTitle);
//            viewHolder.description.setText(postListModels.get(position).description);
//            viewHolder.size.setText(postListModels.get(position).postId.toString());
//            viewHolder.cat_subCat.setText(postListModels.get(position).getCategoryName());
            viewHolder.setData(postListModels.get(position).getPostImage());

            GradientDrawable gd = (GradientDrawable) viewHolder.view_linear.getBackground().getCurrent();
            gd.setColor(color); //set color
            gd.setStroke(1, color, 1, 1);
        }
    }

    public class AroundMeViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public TextView title, cat_subCat, description, size;
        public LinearLayout view_linear;
        public RecyclerView images_grid;
        public ArrayList<String> imagesList;
        public CreatePostImagesAdapter imagesAdapter;

        public AroundMeViewHolder(View itemView) {
            super(itemView);
            images_grid = itemView.findViewById(R.id.images_grid);
            view_linear = itemView.findViewById(R.id.view_linear);
            title = itemView.findViewById(R.id.title);
            cat_subCat = itemView.findViewById(R.id.cat_subCat);
            description = itemView.findViewById(R.id.description);
            size = itemView.findViewById(R.id.size);
            init();
        }

        public void init () {
            /*imagesAdapter*/
            images_grid.setLayoutManager(new GridLayoutManager(context, 1));
            imagesList = new ArrayList<>();
            imagesAdapter = new CreatePostImagesAdapter(context, imagesList, itemClickListener());
            images_grid.setAdapter(imagesAdapter);
        }

        public void setData(List<String> imgsList) {
            imagesList.clear();
            imagesList.addAll(imgsList);
            refreshImgAdapter();
        }

        private void refreshImgAdapter() {
            try {
                if(imagesList.size() <= 1) {
                    images_grid.setLayoutManager(new GridLayoutManager(context, 1));
                    setCells();
                } else if(imagesList.size() == 2) {
                    images_grid.setLayoutManager(new GridLayoutManager(context, 2));
                    setCells();
                } else if(imagesList.size() >= 3) {
                    images_grid.setLayoutManager(new SpannedGridLayoutManager(
                            new SpannedGridLayoutManager.GridSpanLookup() {
                                @Override
                                public SpannedGridLayoutManager.SpanInfo getSpanInfo(int position) {
                                    if (position == 0) {
                                        return new SpannedGridLayoutManager.SpanInfo(2, 2);
                                    } else {
                                        return new SpannedGridLayoutManager.SpanInfo(1, 1);
                                    }
                                }
                            },
                            3 /* Three columns */,
                            1f /* We want our items to be 1:1 ratio */,onCellSizeCalculate()));
//                    if (imagesList.size() >= 10) {
//                        if (imagesList.size() > 10)
//                            Toast.makeText(context,"You can not select more than 10 images.",Toast.LENGTH_SHORT).show();
//                        imagesList.subList(10, imagesList.size()).clear();
//                    }
                } else if(imagesList.size() > 3) {
                    images_grid.setLayoutManager(new SpannedGridLayoutManager (
                            new SpannedGridLayoutManager.GridSpanLookup() {
                                @Override
                                public SpannedGridLayoutManager.SpanInfo getSpanInfo(int position) {
                                    if (position == 0) {
                                        return new SpannedGridLayoutManager.SpanInfo(2, 3);
                                    } else {
                                        return new SpannedGridLayoutManager.SpanInfo(1, 1);
                                    }
                                }
                            },
                            3 /* Three columns */,
                            1f /* We want our items to be 1:1 ratio */));
                }
                imagesAdapter.notifyDataSetChanged();
            } catch (Exception e){
                Log.e(TAG, "refreshImgAdapter: "+e.getMessage());
            }
        }

        private SpannedGridInterface onCellSizeCalculate() {
            return new SpannedGridInterface() {
                @Override
                public void onCalculateWindowSize(int cellHeight, int cellWidth) {
                    if (imagesList.size() <= 2){
                        RelativeLayout.LayoutParams param = (RelativeLayout.LayoutParams) images_grid.getLayoutParams();
                        param.height = cellHeight;
                        images_grid.setLayoutParams(param);
                    } else if (imagesList.size() >= 3){
                        RelativeLayout.LayoutParams param = (RelativeLayout.LayoutParams) images_grid.getLayoutParams();
                        param.height = cellHeight*2;
                        images_grid.setLayoutParams(param);
                    }
                }
            };
        }

        private void setCells() {
            RelativeLayout.LayoutParams param = (RelativeLayout.LayoutParams) images_grid.getLayoutParams();
            param.height = RelativeLayout.LayoutParams.WRAP_CONTENT;
            images_grid.setLayoutParams(param);
        }

        private CreatePostImagesAdapter.ItemClickListener itemClickListener() {
            return new CreatePostImagesAdapter.ItemClickListener() {
                @Override
                public void onItemClick(View view, int position) {
                    Intent in = new Intent(context, PostImagesListActivity.class);
                    in.putStringArrayListExtra("images",imagesList);
                    in.putExtra("position",position);
                    mActivity.startActivityForResult(in,IMAGES);
                }
            };
        }

        @Override
        public void onClick(View v) {}

    }

    private void setAnimation(View viewToAnimate, int position) {
        if (position > lastPosition) {
            Animation animation = AnimationUtils.loadAnimation(context, R.anim.recycler);
            viewToAnimate.startAnimation(animation);
            lastPosition = position;
        } else{
            lastPosition = position;
        }
        if (position == 0)
            lastPosition = -1;
    }

}
