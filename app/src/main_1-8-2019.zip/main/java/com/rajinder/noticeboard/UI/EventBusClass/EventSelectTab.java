package com.rajinder.noticeboard.UI.EventBusClass;

/**
 * Created by rajinder 4/26/2018
 */

public class EventSelectTab {
    int  position;

    public EventSelectTab() {
    }

    public EventSelectTab(int position) {
        this.position = position;
    }


    public int getPosition() {
        return position;
    }
}
