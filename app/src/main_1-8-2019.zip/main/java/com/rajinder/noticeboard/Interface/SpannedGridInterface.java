package com.rajinder.noticeboard.Interface;

import android.net.Uri;

public interface SpannedGridInterface {

    void onCalculateWindowSize(int cellHeight, int cellWidth);

}