package com.rajinder.noticeboard.Interface;

import android.net.Uri;

public interface CreateEventFragmentListener {
    void onFragmentInteraction(Uri uri);
}
